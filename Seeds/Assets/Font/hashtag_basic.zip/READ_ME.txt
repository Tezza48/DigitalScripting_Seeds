This font is licensed under SIL Open Font License Version 1.1
free for personal and commercial use
-------------------------------------------------------------

This is my first as I learned fontlab font so go easy if it 
has errors let me know if you find any let me know. 

comments? Questions? Make something cool with the font that 
I definitely want to see? Email me - mitchstomner@gmail.com